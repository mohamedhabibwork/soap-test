import colors from 'windicss/colors'

export default {
    theme: {
        colors: {
            gray: colors.coolGray
        }
    }
}
