// @ts-ignore
import { withDocus } from 'docus'

export default withDocus({
    rootDir: __dirname,
})
