Libraries for adding WS-* support to ext/soap in PHP.

Currently provides support for employing WS-Security and WS-Addressing when using the native PHP SOAP extension.

The WS-Security library also requires the use of the xmlseclibs library which supports XML-DSIG and XMLENC. 

# Branches
Only the master branch is actively maintained.
* master: Contains namespace support requiring 5.3+.

Mailing List: https://groups.google.com/forum/#!forum/wse-php
