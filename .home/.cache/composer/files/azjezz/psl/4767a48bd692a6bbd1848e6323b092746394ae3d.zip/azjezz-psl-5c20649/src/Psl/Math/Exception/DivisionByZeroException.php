<?php

declare(strict_types=1);

namespace Psl\Math\Exception;

final class DivisionByZeroException extends ArithmeticException
{
}
