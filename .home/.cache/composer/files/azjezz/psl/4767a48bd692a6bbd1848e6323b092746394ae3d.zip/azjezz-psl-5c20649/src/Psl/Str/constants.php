<?php

declare(strict_types=1);

namespace Psl\Str;

const ALPHABET = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
const ALPHABET_ALPHANUMERIC = '0123456789' . ALPHABET;
