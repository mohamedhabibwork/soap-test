# Security

If you discover a security vulnerability within PSL, please send an e-mail to Saif Eddin Gmati via azjezz@protonmail.com.

Please withhold public disclosure until after we have addressed the vulnerability.

There are no hard and fast rules to determine if a bug is worth reporting as a security issue.
