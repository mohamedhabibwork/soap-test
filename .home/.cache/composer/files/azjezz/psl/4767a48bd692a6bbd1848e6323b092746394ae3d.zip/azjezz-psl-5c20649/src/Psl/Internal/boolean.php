<?php

declare(strict_types=1);

namespace Psl\Internal;

/**
 * @pure
 *
 * @codeCoverageIgnore
 *
 * @internal
 */
function boolean(mixed $val): bool
{
    return (bool)$val;
}
