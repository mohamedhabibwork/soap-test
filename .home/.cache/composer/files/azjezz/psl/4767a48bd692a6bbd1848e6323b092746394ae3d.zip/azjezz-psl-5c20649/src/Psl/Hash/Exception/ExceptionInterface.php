<?php

declare(strict_types=1);

namespace Psl\Hash\Exception;

use Psl\Exception;

interface ExceptionInterface extends Exception\ExceptionInterface
{
}
