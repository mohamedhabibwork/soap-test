---
name: ❓ Support Question
about: Have a problem that you can't figure out? 🤔
---

<!-- Fill in the relevant information below to help triage your issue. -->

|    Q        |   A
|------------ | -----
| Version     | x.y.z

<!--
Keep in mind that GitHub is primarily an issue tracker.
-->

### Support Question

<!-- Describe the issue you are facing here. -->