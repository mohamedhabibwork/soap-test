<?php

namespace Phpro\SoapClient\CodeGenerator\Context;

/**
 * Interface ContextInterface
 *
 * @package Phpro\SoapClient\CodeGenerator\Context
 */
interface ContextInterface
{
}
