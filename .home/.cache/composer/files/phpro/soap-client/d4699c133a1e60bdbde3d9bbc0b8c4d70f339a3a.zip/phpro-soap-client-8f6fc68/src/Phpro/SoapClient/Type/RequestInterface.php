<?php

namespace Phpro\SoapClient\Type;

/**
 * Interface RequestInterface
 *
 * This Interface does not contain any methods.
 * The public properties will be used as data for the SOAP requests.
 *
 * @package Phpro\SoapClient\Type
 */
interface RequestInterface
{
}
