<?php

require_once __DIR__.'/../vendor/autoload.php';

define('FIXTURE_DIR', realpath(__DIR__ . '/fixtures'));
define('VCR_CASSETTE_DIR', realpath(__DIR__ . '/fixtures/vcr'));
