<?php

namespace Phpro\SoapClient\Exception;

/**
 * Class RuntimeException
 * @package Phpro\SoapClient\Exception
 */
class RuntimeException extends \RuntimeException
{
}
