<?php

namespace Phpro\SoapClient\Exception;

/**
 * Class RequestException
 *
 * @package Phpro\SoapClient\Exception
 */
class RequestException extends RuntimeException
{

}
